# 🚀 INSTRUCCIONES PARA MILTON (Paso a Paso)

## PASO 1: Descargar la App

1. Descargas la carpeta `comprobantepro` (descargada de Claude Code)
2. La pones en tu Documentos o donde quieras

## PASO 2: Tener Node.js Instalado

Si no lo tienes:
1. Ve a https://nodejs.org
2. Descarga "LTS" (la versión estable)
3. Instala (próximo, próximo, finish)
4. Reinicia la computadora

## PASO 3: Abrir Terminal en la Carpeta

**Windows:**
- Click derecho en la carpeta `comprobantepro`
- "Abrir terminal aquí" o "Open PowerShell here"

**Mac:**
- Click derecho en la carpeta
- "Servicios" → "Nueva ventana Terminal"

**Linux:**
- Click derecho → "Abrir terminal aquí"

## PASO 4: Instalar Dependencias

En la terminal copia y pega esto:

```bash
npm install
```

Espera 2-3 minutos hasta que termine.

## PASO 5: Configurar Firebase

1. Ve a https://console.firebase.google.com
2. Haz click en "Crear Proyecto"
3. Nombre: "ComprobantePro" (o lo que quieras)
4. Sigue los pasos hasta crear
5. En la consola, haz click en "Crear una app web"
6. Copia la configuración que aparece

## PASO 6: Crear Archivo .env.local

1. Abre la carpeta `comprobantepro` en tu editor (VSCode)
2. Crea un archivo nuevo llamado `.env.local` (ojo: punto al inicio)
3. Copia esto y reemplaza con tus valores:

```
VITE_FIREBASE_API_KEY=tu_api_key
VITE_FIREBASE_AUTH_DOMAIN=tu_auth_domain
VITE_FIREBASE_PROJECT_ID=tu_project_id
VITE_FIREBASE_STORAGE_BUCKET=tu_storage_bucket
VITE_FIREBASE_MESSAGING_SENDER_ID=tu_messaging_sender_id
VITE_FIREBASE_APP_ID=tu_app_id
```

## PASO 7: Ejecutar la App

En la terminal pega esto:

```bash
npm run dev
```

Se abrirá automáticamente en http://localhost:3000

## PASO 8: Crear Cuenta

1. Haz click en "¿No tienes cuenta? Regístrate"
2. Llenar email, contraseña, nombre
3. Haz click en "Registrarse"
4. Luego "Iniciar Sesión" con tus datos

## PASO 9: ¡LISTO!

Verás el Dashboard. Ahora puedes:
- Click en "Cargar Comprobante"
- Cargar un comprobante de prueba
- Ver en el Dashboard

## 🆘 TROUBLESHOOTING

### Error: "npm: no se reconoce"
→ No tienes Node.js instalado. Descargá de nodejs.org

### Error: "ENOENT: no such file or directory"
→ Asegurate que estés en la carpeta `comprobantepro`
```bash
cd comprobantepro  # Entra a la carpeta
npm run dev        # Prueba de nuevo
```

### Error: Firebase no funciona
→ Revisa que `.env.local` tenga los datos correctos

### Puerto 3000 en uso
→ Abre otra terminal en la misma carpeta y executa:
```bash
npm run dev -- --port 3001
```

---

**¿Preguntas?** Escribi a quien te pasó esto.

---

## 📋 Resumen: Los 3 Comandos Principales

```bash
# 1. Instalar (una sola vez)
npm install

# 2. Ejecutar localmente (cada vez que quieras usar)
npm run dev

# 3. Parar (cuando quieras cerrar)
Ctrl + C en la terminal
```

¡Eso es todo! ¡A disfrutar ComprobantePro! 🎉
