# ComprobantePro 🎯

Sistema inteligente de gestión de comprobantes de pago. Centraliza, categoriza y valida comprobantes automáticamente.

## ⚡ Inicio Rápido

### 1. Descargar e Instalar Dependencias

```bash
# Descargar Node.js desde https://nodejs.org si no lo tienes
# Abrir terminal en la carpeta comprobantepro

npm install
```

### 2. Configurar Firebase

1. Ve a https://console.firebase.google.com
2. Crea un proyecto nuevo
3. Copia tu configuración de Firebase
4. Crea un archivo `.env.local` en la raíz (cópialo de `.env.example`)
5. Pega tu configuración en `.env.local`

### 3. Ejecutar Localmente

```bash
npm run dev
```

Abre http://localhost:3000 en tu navegador.

## 🔑 Credenciales de Prueba

1. Crea un usuario registrándote en la app
2. O pide a Milton que cree tu cuenta en Firebase

## 📱 Funcionalidades

- ✅ Autenticación segura
- ✅ Carga de comprobantes (JPG, PNG, PDF)
- ✅ Dashboard centralizado
- ✅ Categorización automática
- ✅ Filtros por categoría
- ✅ Almacenamiento en Firebase

## 🚀 Deploy a Firebase Hosting

```bash
# Instalar Firebase CLI (una sola vez)
npm install -g firebase-tools

# Loguear
firebase login

# Deploy
npm run build
firebase deploy
```

Tu app estará en vivo en: `https://tu-proyecto.firebaseapp.com`

## 📁 Estructura de Carpetas

```
comprobantepro/
├── src/
│   ├── components/
│   │   ├── Auth/        # Autenticación
│   │   ├── Dashboard/   # Panel principal
│   │   └── Upload/      # Cargar comprobantes
│   ├── hooks/           # Hooks personalizados
│   ├── services/        # Firebase
│   ├── types/           # TypeScript types
│   ├── App.tsx
│   └── main.tsx
├── package.json
├── .env.local           # Variables secretas
└── README.md
```

## 🛠️ Comandos Útiles

```bash
npm run dev       # Ejecutar localmente
npm run build     # Crear build para producción
npm run preview   # Ver build en local
```

## ⚠️ Importante

- **NO compartas `.env.local`** (contiene datos sensibles)
- Usa `.env.example` como referencia
- Firebase es gratis hasta 1M reads/mes

## 🆘 Errores Comunes

### "npm: no se reconoce"
→ Instala Node.js desde https://nodejs.org

### "Firebase no configado"
→ Llena el archivo `.env.local` correctamente

### "Puerto 3000 en uso"
→ Cambia el puerto en `vite.config.ts`

## 📞 Soporte

Cualquier duda sobre cómo usar la app, pregunta a Milton.
